# Polymorphism

# Polymorphism = having many forms
# In programming, means same function name (but different signatures) being uses for different types

# Polymorphism
# - Duck Typing
# - Operator Overloading
# - Method Overloading
# - Method Overriding