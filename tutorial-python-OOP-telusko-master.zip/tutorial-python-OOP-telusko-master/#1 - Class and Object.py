# Class and Object

class Human:     #Create a class
    def walk(self):   #This is behaviour/function/methods
        print("I'm walking")

#Create an object:
com1 = Human()
com2 = Human()

com1.walk()   #Result : I'm walking
com2.walk()   #Result : I'm walking